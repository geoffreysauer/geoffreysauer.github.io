window.onload = function() {
  var input = document.getElementById("q").focus();
}
